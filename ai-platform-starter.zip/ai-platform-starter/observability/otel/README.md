# OpenTelemetry Collector
Add collector config here.
